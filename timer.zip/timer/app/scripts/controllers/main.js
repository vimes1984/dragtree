'use strict';

angular.module('timerApp')
  .controller('MainCtrl', function () {
});
