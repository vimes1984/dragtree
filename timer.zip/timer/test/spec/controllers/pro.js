'use strict';

describe('Controller: ProCtrl', function () {

  // load the controller's module
  beforeEach(module('timerApp'));

  var ProCtrl,
    scope;

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope) {
    scope = $rootScope.$new();
    ProCtrl = $controller('ProCtrl', {
      $scope: scope
    });
  }));

  it('should attach a list of awesomeThings to the scope', function () {
    expect(scope.awesomeThings.length).toBe(3);
  });
});
